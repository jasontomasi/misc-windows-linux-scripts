<?php

function adminer_object()
	{
		// Load plugin functionality
		include_once "./plugins/plugin.php";
		require_once "./plugins/AdminerTreeViewer.php";

		// Auto-load all PHP files in directory
		foreach (glob("./plugins/*.php") as $filename) {
			include_once "./$filename";
		}

		// Specify enabled plugins here
		$plugins = array(
		new AdminerTreeViewer("script.js"),
		new FillLoginForm("server","","capital","capital",""),
		new AdminerEditTextarea(),
		new AdminerTheme("default-green"),		// AdminerTheme must be the last plugin in the array
		);

		return new AdminerPlugin($plugins);
	}

include "./adminer.php";
