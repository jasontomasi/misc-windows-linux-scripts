/* Copyright (C) 2003  Martin J. Muench <mjm@codito.de> */

#ifndef SENDICMP_H
#define SENDICMP_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in_systm.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>

int sendpacket(int, const unsigned char *, const char *, int, int);
int in_cksum(u_short *, int);
struct sockaddr_in	saddr;

#endif /* SENDICMP_H */
