/* Copyright (C) 2003  Martin J. Muench <mjm@codito.de> */

#ifndef IC_CURSES_H
#define IC_CURSES_H

#include <curses.h>

void start_curses(void);
void end_curses(void);

#endif /* IC_CURSES_H */
