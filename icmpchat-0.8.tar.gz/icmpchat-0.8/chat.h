/* Copyright (C) 2003  Martin J. Muench <mjm@codito.de> */

#ifndef CHAT_H
#define CHAT_H

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <sys/uio.h>
#include <netinet/in_systm.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>
#include <stdarg.h>

int chat(int, const char *, const char *, int, const unsigned char *);

#endif /* CHAT_H */
