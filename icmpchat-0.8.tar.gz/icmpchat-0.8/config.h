/* Copyright (C) 2003  Martin J. Muench <mjm@codito.de> */

#ifndef ICMPCHAT_H
#define	ICMPCHAT_H

#define PROGNAME        "icmpchat"      /* Name of program */
#define	SID		"icmpsid"	/* Session_ID for packet selection	  */

#define VERSION		"0.8"      	/* Well, the version 			  
*/
#define PING		"PING"		/* Authentication String		  */
#define PONG		"PONG"		/* 	"	"			  */

#define BANNER		"\n>>> ---------\n"		\
			">>> ICMP-Chat\n"	\
			">>> ---------\n"		\
			">>> Written by Martin J. Muench <mjm@codito.de>\n"		\
			">>> Take a look at icmpchat.sf.net for updates, bugfixes, etc.\n"\
			">>> For a list of possible commands type '/help'\n"

#define HELP		">>> Help\n"		\
			">>> ----\n"		\
			">>> These are the supported commands:\n"	\
			">>> /quit\tQuit icmpchat\n"			\
			">>> /setname x\tSet name to x\n"		\
			">>> /setcode x\tSet icmpcode to x\n"		\
			">>> /help\tThis message\n"

#define CIPHERBUF        256       /* Size of array buffer */

#endif /* ICMPCHAT_H */
