/* Copyright (C) 2003  Martin J. Muench <mjm@codito.de> */

#ifndef SETUP_H
#define SETUP_H

#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>

#endif /* SETUP_H */
