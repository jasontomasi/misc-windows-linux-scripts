/* Copyright (C) 2003  Martin J. Muench <mjm@codito.de> */

#ifndef WRAP_H
#define WRAP_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h>
#include <errno.h>

int encipher_send(int, const char *, int, int, const unsigned char *, const char *, ...);
int resolv(char *, const char *, int);
int rawsock_setup(void);
void Sigint();

#endif /* WRAP_H */
