/* Copyright (C) 2003  Martin J. Muench <mjm@codito.de> */

#ifndef	DEBUG_H
#define DEBUG_H

#include <stdarg.h>
#include <string.h>
#include <stdio.h>

#ifdef DEBUG
#define debug(x) ic_debug x;
#else 
#define debug(x) do { } while(1!=1);
#endif

void ic_debug(const char *fmt, ...);

#endif /* DEBUG_H */
