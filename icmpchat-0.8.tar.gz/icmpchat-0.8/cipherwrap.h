/* Copyright (C) 2003 Martin J. Muench <mjm@codito.de> */

#ifndef CIPHERWRAP_H
#define CIPHERWRAP_H

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <assert.h>
#include "rijndael.h"

void Getpass(unsigned char *, size_t);

bool encipher_string(const unsigned char *, 
		     unsigned char *, 
		     const char *,
		     ...);

bool decipher_string(const unsigned char*,
		     unsigned char *,
		     const unsigned char *);

#endif /* CIPHERWRAP_H */
